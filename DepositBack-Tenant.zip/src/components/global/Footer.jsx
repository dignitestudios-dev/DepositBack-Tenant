import React from 'react';

const Footer = () => {
  return (
    <div className='bottom-0 left-0 right-0 border-t-2 border-slate-200 p-5 text-center text-sm mt-10'>
      2025 Copyright reserves. Deposit Back
    </div>
  );
};

export default Footer;
