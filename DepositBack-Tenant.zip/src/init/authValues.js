export const signUpValues = {
  fname: "",
  lname: "",
  email: "",
  number: "",
  password: "",
  cPassword: "",
};

export const signInValues = {
  email: "",
  password: "",
};

export const updatePasswordValues = {
  password: "",
  cPassword: "",
};

export const personalInfoValues = {
  idFront: null,
  idFrontPreview: null,
  idBack: null,
  idBackPreview: null,
  profileImage: null,
  profilePreview: null,
};
